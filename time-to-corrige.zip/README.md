# Time To

Application Angular qui répond à la question : « quand puis-je faire mon activité en extérieur cette semaine ? ».
Données : [Open-Meteo](https://open-meteo.com/) (CC BY 4.0), sans clé d'API ni backend.

## Prérequis

- Node.js 22.22.3 ou plus, ou 24.15 ou plus (exigence d'Angular 22)
- npm

## Commandes

| Commande | Rôle |
|---|---|
| `npm install` | Installer les dépendances |
| `npx ng serve` | Serveur de développement sur http://localhost:4200 |
| `npx ng test` | Tests unitaires (Vitest) en mode surveillance |
| `npx ng test --watch=false` | Tests unitaires, exécution unique |
| `npx ng lint` | Analyse statique (angular-eslint) |
| `npx ng build` | Build de production dans `dist/time-to/browser` |

## Architecture

```
src/app/
├── core/          services techniques transverses
│   ├── api/           accès Open-Meteo, modèles, validation, transformation
│   ├── http/          intercepteurs HTTP
│   └── preferences/   préférences persistées (localStorage)
├── domain/        logique métier pure (profils d'activité, scoring) : aucune dépendance Angular
├── features/      écrans et composants par fonctionnalité
│   ├── home/  search/  forecast/  settings/  not-found/
└── shared/        éléments réutilisables (pipe, directive)
```

## Déploiement

Le workflow `.github/workflows/ci.yml` exécute lint, tests et build à chaque push,
puis publie sur GitHub Pages depuis `main`.
Activer au préalable : Settings → Pages → Source : **GitHub Actions**.

## Sécurité

La build de production utilise `src/index.prod.html`, qui déclare une Content Security Policy
n'autorisant que les scripts de l'application et les appels vers les trois domaines Open-Meteo.
