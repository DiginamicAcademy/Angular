import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ScoreLevelDirective, scoreLevel } from './score-level';

describe('scoreLevel', () => {
  it.each([
    [0, 'faible'],
    [39, 'faible'],
    [40, 'moyen'],
    [59, 'moyen'],
    [60, 'bon'],
    [100, 'bon'],
  ])('%i → %s', (score, expected) => {
    expect(scoreLevel(score)).toBe(expected);
  });
});

@Component({
  imports: [ScoreLevelDirective],
  template: `<span [appScoreLevel]="score()">{{ score() }}</span>`,
})
class Host {
  readonly score = signal(20);
}

describe('ScoreLevelDirective', () => {
  it("met à jour l'attribut data-level", async () => {
    const fixture = TestBed.createComponent(Host);
    await fixture.whenStable();
    const span = (fixture.nativeElement as HTMLElement).querySelector('span')!;
    expect(span.dataset['level']).toBe('faible');

    fixture.componentInstance.score.set(80);
    await fixture.whenStable();
    expect(span.dataset['level']).toBe('bon');
  });
});
