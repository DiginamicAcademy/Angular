import { Directive, computed, input } from '@angular/core';

export type ScoreLevel = 'faible' | 'moyen' | 'bon';

/** Niveau d'un score : moins de 40, moins de 60, 60 et plus. */
export function scoreLevel(score: number): ScoreLevel {
  return score >= 60 ? 'bon' : score >= 40 ? 'moyen' : 'faible';
}

/**
 * Directive d'attribut : indique le niveau d'un score sur l'élément hôte
 * (attribut data-level), pour le styliser en CSS.
 * Usage : <td [appScoreLevel]="hour.score">{{ hour.score }}</td>
 */
@Directive({
  selector: '[appScoreLevel]',
  host: { '[attr.data-level]': 'level()' },
})
export class ScoreLevelDirective {
  readonly appScoreLevel = input.required<number>();

  protected readonly level = computed(() => scoreLevel(this.appScoreLevel()));
}
