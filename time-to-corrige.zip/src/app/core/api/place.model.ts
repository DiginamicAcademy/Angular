/** Un lieu choisi par l'utilisateur. */
export interface Place {
  name: string;
  latitude: number;
  longitude: number;
}
