import { HourConditions } from '../../domain/hour-conditions.model';
import { AirQualityResponse, ForecastResponse } from './open-meteo.models';

/**
 * Transforme les tableaux parallèles de l'API en une liste d'heures,
 * fusionne la qualité de l'air par horodatage et écarte les heures passées.
 */
export function toHourConditions(
  forecast: ForecastResponse,
  airQuality?: AirQualityResponse,
): HourConditions[] {
  const aqiByTime = new Map<string, number>();
  if (airQuality) {
    airQuality.hourly.time.forEach((time, index) => {
      const aqi = airQuality.hourly.european_aqi[index];
      if (aqi !== null && aqi !== undefined) {
        aqiByTime.set(time, aqi);
      }
    });
  }

  // "2026-09-19T14:15" → "2026-09-19T14:00" : l'heure courante, à l'heure locale du lieu.
  const currentHour = `${forecast.current.time.slice(0, 13)}:00`;
  const { hourly } = forecast;

  return hourly.time
    .map((time, index) => ({
      time,
      temperature: hourly.temperature_2m[index],
      rainProbability: hourly.precipitation_probability[index] ?? null,
      windSpeed: hourly.wind_speed_10m[index],
      weatherCode: hourly.weather_code[index],
      isDay: hourly.is_day[index] === 1,
      aqi: aqiByTime.get(time),
    }))
    .filter((hour) => hour.time >= currentHour);
}
