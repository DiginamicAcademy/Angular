import { ForecastResponse } from './open-meteo.models';

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function isNumberArray(value: unknown): value is number[] {
  return Array.isArray(value) && value.every((item) => typeof item === 'number');
}

/**
 * Les types TypeScript disparaissent à l'exécution : ce garde vérifie
 * réellement la forme de la réponse avant qu'elle n'entre dans l'application.
 */
export function isForecastResponse(value: unknown): value is ForecastResponse {
  if (!isRecord(value) || !isRecord(value['hourly']) || !isRecord(value['current'])) {
    return false;
  }
  const hourly = value['hourly'];
  const time = hourly['time'];
  return (
    Array.isArray(time) &&
    time.every((item) => typeof item === 'string') &&
    isNumberArray(hourly['temperature_2m']) &&
    isNumberArray(hourly['wind_speed_10m']) &&
    isNumberArray(hourly['weather_code']) &&
    isNumberArray(hourly['is_day']) &&
    Array.isArray(hourly['precipitation_probability'])
  );
}

/** Fonction `parse` pour httpResource : lève une erreur si la réponse est invalide. */
export function parseForecast(value: unknown): ForecastResponse {
  if (!isForecastResponse(value)) {
    throw new Error('Réponse météo inattendue');
  }
  return value;
}
