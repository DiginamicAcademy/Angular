import { AirQualityResponse, ForecastResponse } from './open-meteo.models';
import { toHourConditions } from './to-hour-conditions';

const forecast: ForecastResponse = {
  latitude: 43.61,
  longitude: 3.88,
  timezone: 'Europe/Paris',
  current: { time: '2026-09-19T13:45', temperature_2m: 24, weather_code: 1 },
  hourly: {
    time: ['2026-09-19T12:00', '2026-09-19T13:00', '2026-09-19T14:00'],
    temperature_2m: [23, 24, 25],
    precipitation_probability: [0, null, 10],
    wind_speed_10m: [10, 12, 14],
    weather_code: [0, 1, 2],
    is_day: [1, 1, 1],
  },
};

describe('toHourConditions', () => {
  it("écarte les heures passées et conserve l'heure en cours", () => {
    const hours = toHourConditions(forecast);
    expect(hours.map((h) => h.time)).toEqual(['2026-09-19T13:00', '2026-09-19T14:00']);
  });

  it('convertit les tableaux parallèles en objets', () => {
    const [first] = toHourConditions(forecast);
    expect(first).toEqual({
      time: '2026-09-19T13:00',
      temperature: 24,
      rainProbability: null,
      windSpeed: 12,
      weatherCode: 1,
      isDay: true,
      aqi: undefined,
    });
  });

  it('fusionne la qualité de l’air par horodatage', () => {
    const air: AirQualityResponse = {
      hourly: { time: ['2026-09-19T14:00'], european_aqi: [42] },
    };
    const hours = toHourConditions(forecast, air);
    expect(hours[0].aqi).toBeUndefined();
    expect(hours[1].aqi).toBe(42);
  });
});
