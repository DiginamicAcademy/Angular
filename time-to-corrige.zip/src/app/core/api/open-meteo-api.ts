import { Service } from '@angular/core';
import { httpResource } from '@angular/common/http';
import { parseForecast } from './open-meteo-validation';
import { AirQualityResponse, GeocodingResponse, GeocodingResult } from './open-meteo.models';
import { Place } from './place.model';

const FORECAST_URL = 'https://api.open-meteo.com/v1/forecast';
const AIR_QUALITY_URL = 'https://air-quality-api.open-meteo.com/v1/air-quality';
const GEOCODING_URL = 'https://geocoding-api.open-meteo.com/v1/search';

/**
 * Accès à l'API Open-Meteo. Chaque méthode crée un `httpResource` :
 * elle doit donc être appelée dans un contexte d'injection
 * (initialisation d'un champ de composant, par exemple).
 * Quand la fonction de requête renvoie `undefined`, aucune requête n'est envoyée.
 */
@Service()
export class OpenMeteoApi {
  forecast(place: () => Place | undefined) {
    return httpResource(
      () => {
        const p = place();
        return p
          ? {
              url: FORECAST_URL,
              params: {
                latitude: p.latitude,
                longitude: p.longitude,
                current: 'temperature_2m,weather_code',
                hourly:
                  'temperature_2m,precipitation_probability,wind_speed_10m,weather_code,is_day',
                timezone: 'auto',
                forecast_days: 7,
              },
            }
          : undefined;
      },
      { parse: parseForecast },
    );
  }

  airQuality(place: () => Place | undefined) {
    return httpResource<AirQualityResponse>(() => {
      const p = place();
      return p
        ? {
            url: AIR_QUALITY_URL,
            params: {
              latitude: p.latitude,
              longitude: p.longitude,
              hourly: 'european_aqi',
              timezone: 'auto',
              forecast_days: 5,
            },
          }
        : undefined;
    });
  }

  searchPlaces(query: () => string) {
    return httpResource<GeocodingResult[]>(
      () => {
        const name = query().trim();
        return name.length >= 2
          ? { url: GEOCODING_URL, params: { name, count: 8, language: 'fr' } }
          : undefined;
      },
      {
        defaultValue: [],
        parse: (raw) => (raw as GeocodingResponse).results ?? [],
      },
    );
  }
}
