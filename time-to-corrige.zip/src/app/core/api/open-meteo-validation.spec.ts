import { isForecastResponse, parseForecast } from './open-meteo-validation';

describe('isForecastResponse', () => {
  it('refuse les valeurs qui ne sont pas des objets', () => {
    expect(isForecastResponse(null)).toBe(false);
    expect(isForecastResponse('texte')).toBe(false);
  });

  it("refuse une réponse d'erreur de l'API", () => {
    expect(isForecastResponse({ error: true, reason: 'Paramètre invalide' })).toBe(false);
  });

  it('lève une erreur explicite via parseForecast', () => {
    expect(() => parseForecast({})).toThrow('Réponse météo inattendue');
  });
});
