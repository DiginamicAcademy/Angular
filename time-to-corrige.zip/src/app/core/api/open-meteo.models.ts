/** Réponse de /v1/forecast pour les variables demandées par l'application. */
export interface ForecastResponse {
  latitude: number;
  longitude: number;
  timezone: string;
  current: {
    time: string;
    temperature_2m: number;
    weather_code: number;
  };
  hourly: {
    time: string[];
    temperature_2m: number[];
    precipitation_probability: (number | null)[];
    wind_speed_10m: number[];
    weather_code: number[];
    is_day: number[];
  };
}

/** Réponse de /v1/air-quality. */
export interface AirQualityResponse {
  hourly: {
    time: string[];
    european_aqi: (number | null)[];
  };
}

/** Un résultat du géocodage. Les champs vides ne sont pas renvoyés par l'API. */
export interface GeocodingResult {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  country?: string;
  country_code?: string;
  admin1?: string;
}

/** `results` est absent quand aucun lieu ne correspond. */
export interface GeocodingResponse {
  results?: GeocodingResult[];
}
