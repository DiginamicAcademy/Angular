import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { retry, throwError, timer } from 'rxjs';

/** Codes pour lesquels une nouvelle tentative a du sens : réseau coupé (0), surcharge, erreur serveur. */
function isTransient(error: unknown): boolean {
  return error instanceof HttpErrorResponse && (error.status === 0 || error.status >= 500);
}

/**
 * Intercepteur fonctionnel : relance une fois, après 1 seconde,
 * les requêtes GET qui échouent pour une raison passagère.
 */
export const retryInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.method !== 'GET') {
    return next(req);
  }
  return next(req).pipe(
    retry({
      count: 1,
      delay: (error: unknown) => (isTransient(error) ? timer(1000) : throwError(() => error)),
    }),
  );
};
