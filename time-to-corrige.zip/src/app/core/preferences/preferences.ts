import { Service, computed, effect, signal } from '@angular/core';
import { ActivityId, ActivityProfile } from '../../domain/activity.model';
import { DEFAULT_ACTIVITIES } from '../../domain/activities';
import { Place } from '../api/place.model';

interface StoredPreferences {
  activities: ActivityProfile[];
  lastPlace?: Place;
}

const STORAGE_KEY = 'time-to.preferences.v1';

function defaults(): StoredPreferences {
  return { activities: DEFAULT_ACTIVITIES.map((activity) => ({ ...activity })) };
}

/** Lecture défensive : le contenu du localStorage n'est pas fiable. */
function load(): StoredPreferences {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return defaults();
    }
    const parsed: unknown = JSON.parse(raw);
    if (
      typeof parsed === 'object' &&
      parsed !== null &&
      Array.isArray((parsed as StoredPreferences).activities)
    ) {
      return parsed as StoredPreferences;
    }
  } catch {
    // stockage indisponible ou JSON corrompu : on repart des valeurs par défaut
  }
  return defaults();
}

/** Préférences de l'utilisateur, conservées dans le navigateur. */
@Service()
export class Preferences {
  private readonly state = signal<StoredPreferences>(load());

  readonly activities = computed(() => this.state().activities);
  readonly lastPlace = computed(() => this.state().lastPlace);

  constructor() {
    // Chaque modification de l'état est sauvegardée automatiquement.
    effect(() => {
      const snapshot = this.state();
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
      } catch {
        // quota dépassé ou navigation privée : on ignore
      }
    });
  }

  activity(id: ActivityId): ActivityProfile | undefined {
    return this.activities().find((activity) => activity.id === id);
  }

  updateActivity(updated: ActivityProfile): void {
    this.state.update((prefs) => ({
      ...prefs,
      activities: prefs.activities.map((activity) =>
        activity.id === updated.id ? { ...updated } : activity,
      ),
    }));
  }

  rememberPlace(place: Place): void {
    this.state.update((prefs) => ({ ...prefs, lastPlace: place }));
  }

  reset(): void {
    this.state.set(defaults());
  }
}
