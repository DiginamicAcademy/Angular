import { Routes } from '@angular/router';
import { HomePage } from './features/home/home-page';

export const routes: Routes = [
  { path: '', component: HomePage, title: 'Time To' },
  {
    path: 'prevision/:lat/:lon',
    // Chargement différé : le code de la page n'est téléchargé qu'à la première visite.
    loadComponent: () => import('./features/forecast/forecast-page').then((m) => m.ForecastPage),
    title: 'Time To · Prévisions',
  },
  {
    path: 'reglages/:activite',
    loadComponent: () => import('./features/settings/settings-page').then((m) => m.SettingsPage),
    title: 'Time To · Réglages',
  },
  {
    path: '**',
    loadComponent: () =>
      import('./features/not-found/not-found-page').then((m) => m.NotFoundPage),
    title: 'Time To · Page introuvable',
  },
];
