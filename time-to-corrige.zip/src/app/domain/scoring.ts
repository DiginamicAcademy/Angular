import { ActivityProfile } from './activity.model';
import { HourConditions } from './hour-conditions.model';

/** Une heure accompagnée de son score (0 à 100). */
export interface ScoredHour extends HourConditions {
  score: number;
}

/** Un créneau : une suite d'heures consécutives favorables. */
export interface Slot {
  start: string;
  end: string;
  hours: number;
  averageScore: number;
  minTemperature: number;
  maxTemperature: number;
  maxWind: number;
  maxRainProbability: number;
}

export interface SlotOptions {
  /** Score minimal pour qu'une heure soit retenue. */
  minScore: number;
  /** Durée minimale d'un créneau, en heures. */
  minHours: number;
  /** Nombre maximal de créneaux renvoyés. */
  limit: number;
}

const DEFAULT_SLOT_OPTIONS: SlotOptions = { minScore: 60, minHours: 2, limit: 3 };

/** Borne une valeur entre 0 et 1. */
function clamp01(value: number): number {
  return Math.min(1, Math.max(0, value));
}

/** 1 dans la plage idéale, puis décroissance linéaire jusqu'à 0 à `tolerance` degrés. */
export function temperatureFactor(temperature: number, profile: ActivityProfile): number {
  if (temperature >= profile.idealMin && temperature <= profile.idealMax) {
    return 1;
  }
  const gap =
    temperature < profile.idealMin
      ? profile.idealMin - temperature
      : temperature - profile.idealMax;
  return clamp01(1 - gap / profile.tolerance);
}

/** 1 jusqu'à la moitié du vent maximal, puis décroissance linéaire jusqu'à 0 au maximum. */
export function windFactor(windSpeed: number, profile: ActivityProfile): number {
  const comfortable = profile.maxWind / 2;
  if (windSpeed <= comfortable) {
    return 1;
  }
  return clamp01(1 - (windSpeed - comfortable) / (profile.maxWind - comfortable));
}

/** 0 au-delà du seuil ; sinon légère pénalité proportionnelle à la probabilité. */
export function rainFactor(rainProbability: number | null, profile: ActivityProfile): number {
  if (rainProbability === null) {
    return 0.8; // donnée absente : on reste prudent
  }
  if (rainProbability > profile.maxRainProbability) {
    return 0;
  }
  return 1 - rainProbability / 200;
}

/** Forte pénalité si la qualité de l'air dépasse le seuil du profil. */
export function airFactor(aqi: number | undefined, profile: ActivityProfile): number {
  if (aqi === undefined || profile.maxAqi === undefined) {
    return 1;
  }
  return aqi <= profile.maxAqi ? 1 : 0.3;
}

/** Score d'une heure pour un profil, entre 0 et 100. Fonction pure. */
export function scoreHour(hour: HourConditions, profile: ActivityProfile): number {
  if (profile.daylightOnly && !hour.isDay) {
    return 0;
  }
  const score =
    temperatureFactor(hour.temperature, profile) *
    windFactor(hour.windSpeed, profile) *
    rainFactor(hour.rainProbability, profile) *
    airFactor(hour.aqi, profile);
  return Math.round(score * 100);
}

/** Calcule le score de chaque heure. */
export function scoreHours(hours: readonly HourConditions[], profile: ActivityProfile): ScoredHour[] {
  return hours.map((hour) => ({ ...hour, score: scoreHour(hour, profile) }));
}

function toSlot(group: readonly ScoredHour[]): Slot {
  const total = group.reduce((sum, hour) => sum + hour.score, 0);
  const temperatures = group.map((hour) => hour.temperature);
  return {
    start: group[0].time,
    end: group[group.length - 1].time,
    hours: group.length,
    averageScore: Math.round(total / group.length),
    minTemperature: Math.min(...temperatures),
    maxTemperature: Math.max(...temperatures),
    maxWind: Math.max(...group.map((hour) => hour.windSpeed)),
    maxRainProbability: Math.max(...group.map((hour) => hour.rainProbability ?? 0)),
  };
}

/**
 * Regroupe les heures consécutives dont le score atteint `minScore`,
 * écarte les groupes trop courts et renvoie les meilleurs créneaux.
 */
export function findSlots(
  hours: readonly ScoredHour[],
  options: Partial<SlotOptions> = {},
): Slot[] {
  const { minScore, minHours, limit } = { ...DEFAULT_SLOT_OPTIONS, ...options };
  const groups: ScoredHour[][] = [];
  let current: ScoredHour[] = [];

  for (const hour of hours) {
    if (hour.score >= minScore) {
      current.push(hour);
    } else if (current.length > 0) {
      groups.push(current);
      current = [];
    }
  }
  if (current.length > 0) {
    groups.push(current);
  }

  return groups
    .filter((group) => group.length >= minHours)
    .map(toSlot)
    .sort((a, b) => b.averageScore - a.averageScore || b.hours - a.hours)
    .slice(0, limit);
}
