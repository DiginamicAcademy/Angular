/** Identifiants des activités proposées : un type union de littéraux. */
export type ActivityId = 'velo' | 'rando' | 'course' | 'linge';

/** Profil d'une activité : les seuils utilisés par le calcul du score. */
export interface ActivityProfile {
  readonly id: ActivityId;
  label: string;
  emoji: string;
  /** Plage de température idéale, en °C. */
  idealMin: number;
  idealMax: number;
  /** Écart (en °C) hors de la plage idéale au-delà duquel le score tombe à 0. */
  tolerance: number;
  /** Vent maximal acceptable, en km/h. */
  maxWind: number;
  /** Probabilité de pluie maximale acceptable, en %. */
  maxRainProbability: number;
  /** L'activité n'a de sens qu'en journée. */
  daylightOnly: boolean;
  /** Indice européen de qualité de l'air maximal acceptable (optionnel). */
  maxAqi?: number;
}
