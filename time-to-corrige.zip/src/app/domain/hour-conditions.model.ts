/** Conditions météo d'une heure, dans un format indépendant de l'API. */
export interface HourConditions {
  /** Heure locale du lieu, au format ISO sans fuseau : "2026-09-19T14:00". */
  time: string;
  temperature: number;
  /** Probabilité de pluie en %, `null` si le modèle ne la fournit pas. */
  rainProbability: number | null;
  windSpeed: number;
  weatherCode: number;
  isDay: boolean;
  /** Indice européen de qualité de l'air, absent au-delà de l'horizon de prévision. */
  aqi?: number;
}
