import { ActivityProfile } from './activity.model';
import { HourConditions } from './hour-conditions.model';
import {
  ScoredHour,
  findSlots,
  rainFactor,
  scoreHour,
  temperatureFactor,
  windFactor,
} from './scoring';

const velo: ActivityProfile = {
  id: 'velo',
  label: 'Vélo',
  emoji: '🚴',
  idealMin: 15,
  idealMax: 25,
  tolerance: 10,
  maxWind: 30,
  maxRainProbability: 30,
  daylightOnly: true,
};

/** Fabrique une heure « parfaite », modifiable au cas par cas. */
function hour(overrides: Partial<HourConditions> = {}): HourConditions {
  return {
    time: '2026-09-19T14:00',
    temperature: 20,
    rainProbability: 0,
    windSpeed: 5,
    weatherCode: 0,
    isDay: true,
    ...overrides,
  };
}

describe('temperatureFactor', () => {
  it('vaut 1 dans la plage idéale, bornes comprises', () => {
    expect(temperatureFactor(15, velo)).toBe(1);
    expect(temperatureFactor(25, velo)).toBe(1);
  });

  it('décroît linéairement hors de la plage', () => {
    expect(temperatureFactor(10, velo)).toBeCloseTo(0.5);
    expect(temperatureFactor(30, velo)).toBeCloseTo(0.5);
  });

  it('vaut 0 au-delà de la tolérance', () => {
    expect(temperatureFactor(0, velo)).toBe(0);
    expect(temperatureFactor(40, velo)).toBe(0);
  });
});

describe('windFactor', () => {
  it('vaut 1 jusqu’à la moitié du vent maximal', () => {
    expect(windFactor(15, velo)).toBe(1);
  });

  it('vaut 0 au vent maximal et au-delà', () => {
    expect(windFactor(30, velo)).toBe(0);
    expect(windFactor(50, velo)).toBe(0);
  });
});

describe('rainFactor', () => {
  it('vaut 0 au-delà du seuil', () => {
    expect(rainFactor(31, velo)).toBe(0);
  });

  it('reste prudent quand la donnée est absente', () => {
    expect(rainFactor(null, velo)).toBe(0.8);
  });
});

describe('scoreHour', () => {
  it('donne 100 pour des conditions idéales', () => {
    expect(scoreHour(hour(), velo)).toBe(100);
  });

  it('donne 0 la nuit pour une activité de jour', () => {
    expect(scoreHour(hour({ isDay: false }), velo)).toBe(0);
  });

  it('pénalise une mauvaise qualité de l’air si le profil fixe un seuil', () => {
    const rando: ActivityProfile = { ...velo, id: 'rando', maxAqi: 50 };
    expect(scoreHour(hour({ aqi: 80 }), rando)).toBe(30);
    expect(scoreHour(hour({ aqi: 80 }), velo)).toBe(100);
  });

  it('ne pénalise pas une qualité de l’air sous le seuil', () => {
    const rando: ActivityProfile = { ...velo, id: 'rando', maxAqi: 50 };
    expect(scoreHour(hour({ aqi: 20 }), rando)).toBe(100);
  });
});

describe('findSlots', () => {
  /** Construit une journée à partir d'une liste de scores, une heure par score. */
  function day(scores: number[]): ScoredHour[] {
    return scores.map((score, index) => ({
      ...hour({ time: `2026-09-19T${String(index).padStart(2, '0')}:00` }),
      score,
    }));
  }

  it('regroupe les heures consécutives favorables', () => {
    const slots = findSlots(day([0, 80, 90, 70, 0, 65, 0]));
    expect(slots).toHaveLength(1);
    expect(slots[0]).toMatchObject({
      start: '2026-09-19T01:00',
      end: '2026-09-19T03:00',
      hours: 3,
      averageScore: 80,
    });
  });

  it('écarte les créneaux trop courts', () => {
    expect(findSlots(day([90, 0, 90, 0]))).toEqual([]);
  });

  it('trie par score moyen et limite le nombre de résultats', () => {
    const slots = findSlots(day([70, 70, 0, 95, 95, 0, 80, 80, 0, 60, 60]), { limit: 2 });
    expect(slots.map((s) => s.averageScore)).toEqual([95, 80]);
  });

  it('départage deux créneaux de même score par leur durée', () => {
    const slots = findSlots(day([80, 80, 0, 80, 80, 80]));
    expect(slots.map((s) => s.hours)).toEqual([3, 2]);
  });

  it('compte une probabilité de pluie inconnue comme nulle dans le résumé', () => {
    const hours = day([90, 90]).map((h) => ({ ...h, rainProbability: null }));
    expect(findSlots(hours)[0].maxRainProbability).toBe(0);
  });

  it('prend en compte un créneau qui se termine avec la dernière heure', () => {
    expect(findSlots(day([0, 75, 75]))).toHaveLength(1);
  });
});
