import { Component, computed, inject, input, numberAttribute } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { OpenMeteoApi } from '../../core/api/open-meteo-api';
import { Place } from '../../core/api/place.model';
import { toHourConditions } from '../../core/api/to-hour-conditions';
import { Preferences } from '../../core/preferences/preferences';
import { ActivityId } from '../../domain/activity.model';
import { findSlots, scoreHours } from '../../domain/scoring';
import { WeatherLabelPipe } from '../../shared/pipes/weather-label-pipe';
import { ActivityPicker } from './activity-picker';
import { HourlyTable } from './hourly-table';
import { SlotList } from './slot-list';

@Component({
  selector: 'app-forecast-page',
  imports: [ActivityPicker, HourlyTable, SlotList, RouterLink, WeatherLabelPipe],
  templateUrl: './forecast-page.html',
})
export class ForecastPage {
  private readonly api = inject(OpenMeteoApi);
  private readonly router = inject(Router);
  protected readonly preferences = inject(Preferences);

  // Paramètres de route (:lat, :lon) et de requête (?nom=…&activite=…),
  // liés automatiquement grâce à withComponentInputBinding().
  readonly lat = input.required({ transform: numberAttribute });
  readonly lon = input.required({ transform: numberAttribute });
  readonly nom = input<string>();
  readonly activite = input<string>();

  protected readonly place = computed<Place | undefined>(() => {
    const latitude = this.lat();
    const longitude = this.lon();
    const valid =
      Number.isFinite(latitude) &&
      Number.isFinite(longitude) &&
      Math.abs(latitude) <= 90 &&
      Math.abs(longitude) <= 180;
    return valid ? { name: this.nom() ?? 'Lieu choisi', latitude, longitude } : undefined;
  });

  protected readonly activity = computed(() => {
    const all = this.preferences.activities();
    return all.find((a) => a.id === this.activite()) ?? all[0];
  });

  protected readonly forecast = this.api.forecast(this.place);
  protected readonly airQuality = this.api.airQuality(this.place);

  protected readonly scoredHours = computed(() => {
    if (!this.forecast.hasValue()) {
      return [];
    }
    // La qualité de l'air est un bonus : si elle échoue, on calcule sans elle.
    const air = this.airQuality.hasValue() ? this.airQuality.value() : undefined;
    return scoreHours(toHourConditions(this.forecast.value(), air), this.activity());
  });

  protected readonly slots = computed(() => findSlots(this.scoredHours()));

  protected selectActivity(id: ActivityId): void {
    void this.router.navigate([], {
      queryParams: { activite: id },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }
}
