import { Component, input, output } from '@angular/core';
import { ActivityId, ActivityProfile } from '../../domain/activity.model';

@Component({
  selector: 'app-activity-picker',
  template: `
    <fieldset>
      <legend>Activité</legend>
      <div class="chips">
        @for (activity of activities(); track activity.id) {
          <button
            type="button"
            [class.active]="activity.id === selected()"
            [attr.aria-pressed]="activity.id === selected()"
            (click)="selectedChange.emit(activity.id)"
          >
            {{ activity.emoji }} {{ activity.label }}
          </button>
        }
      </div>
    </fieldset>
  `,
  styles: `
    fieldset { border: none; padding: 0; margin: 0; }
    .chips { display: flex; flex-wrap: wrap; gap: 0.5rem; }
    .active { background: var(--accent); color: var(--on-accent); }
  `,
})
export class ActivityPicker {
  readonly activities = input.required<readonly ActivityProfile[]>();
  readonly selected = input.required<ActivityId>();
  readonly selectedChange = output<ActivityId>();
}
