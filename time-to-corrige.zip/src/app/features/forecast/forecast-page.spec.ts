import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { ForecastResponse } from '../../core/api/open-meteo.models';
import { ForecastPage } from './forecast-page';

const response: ForecastResponse = {
  latitude: 43.61,
  longitude: 3.88,
  timezone: 'Europe/Paris',
  current: { time: '2026-09-19T09:00', temperature_2m: 19, weather_code: 0 },
  hourly: {
    time: ['2026-09-19T09:00', '2026-09-19T10:00', '2026-09-19T11:00'],
    temperature_2m: [19, 20, 21],
    precipitation_probability: [0, 0, 0],
    wind_speed_10m: [5, 5, 5],
    weather_code: [0, 0, 0],
    is_day: [1, 1, 1],
  },
};

describe('ForecastPage', () => {
  let http: HttpTestingController;

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])],
    });
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  async function createPage() {
    const fixture = TestBed.createComponent(ForecastPage);
    fixture.componentRef.setInput('lat', '43.61');
    fixture.componentRef.setInput('lon', '3.88');
    fixture.componentRef.setInput('nom', 'Montpellier');
    // Exécute les effets : les httpResource envoient alors leurs requêtes.
    // (whenStable() attendrait indéfiniment la fin des requêtes en cours.)
    TestBed.tick();
    return fixture;
  }

  it('interroge Open-Meteo et affiche les créneaux', async () => {
    const fixture = await createPage();

    const forecastRequest = http.expectOne((req) => req.url.endsWith('/v1/forecast'));
    expect(forecastRequest.request.params.get('latitude')).toBe('43.61');
    forecastRequest.flush(response);
    http.expectOne((req) => req.url.endsWith('/v1/air-quality')).flush({
      hourly: { time: [], european_aqi: [] },
    });
    await fixture.whenStable();

    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';
    expect(text).toContain('Montpellier');
    expect(text).toContain('Score moyen : 100/100');
  });

  it('affiche un message si la requête météo échoue', async () => {
    const fixture = await createPage();

    http
      .expectOne((req) => req.url.endsWith('/v1/forecast'))
      .flush('Erreur', { status: 400, statusText: 'Bad Request' });
    http.expectOne((req) => req.url.endsWith('/v1/air-quality')).flush({
      hourly: { time: [], european_aqi: [] },
    });
    await fixture.whenStable();

    const alert = (fixture.nativeElement as HTMLElement).querySelector('[role="alert"]');
    expect(alert?.textContent).toContain('Impossible de récupérer les prévisions');
  });

  it('signale des coordonnées invalides sans appeler l’API', async () => {
    const fixture = TestBed.createComponent(ForecastPage);
    fixture.componentRef.setInput('lat', 'abc');
    fixture.componentRef.setInput('lon', '3.88');
    TestBed.tick();

    http.expectNone(() => true);
    expect((fixture.nativeElement as HTMLElement).textContent).toContain('Coordonnées invalides');
  });
});
