import { Component, computed, input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ScoredHour } from '../../domain/scoring';
import { ScoreLevelDirective } from '../../shared/directives/score-level';
import { WeatherLabelPipe } from '../../shared/pipes/weather-label-pipe';

@Component({
  selector: 'app-hourly-table',
  imports: [DatePipe, WeatherLabelPipe, ScoreLevelDirective],
  templateUrl: './hourly-table.html',
  styleUrl: './hourly-table.css',
})
export class HourlyTable {
  readonly hours = input.required<readonly ScoredHour[]>();
  /** Score à partir duquel une heure est mise en évidence. */
  readonly highlightFrom = input(60);

  /** Regroupement par jour : "2026-09-19T14:00" → clé "2026-09-19". */
  protected readonly days = computed(() => {
    const byDay = new Map<string, ScoredHour[]>();
    for (const hour of this.hours()) {
      const day = hour.time.slice(0, 10);
      byDay.set(day, [...(byDay.get(day) ?? []), hour]);
    }
    return [...byDay.entries()].map(([day, hours]) => ({ day, hours }));
  });
}
