import { TestBed } from '@angular/core/testing';
import { Slot } from '../../domain/scoring';
import { SlotList } from './slot-list';

const slot: Slot = {
  start: '2026-09-19T10:00',
  end: '2026-09-19T13:00',
  hours: 4,
  averageScore: 88,
  minTemperature: 18,
  maxTemperature: 23,
  maxWind: 12,
  maxRainProbability: 5,
};

describe('SlotList', () => {
  it('affiche un message quand il n’y a aucun créneau', async () => {
    const fixture = TestBed.createComponent(SlotList);
    fixture.componentRef.setInput('slots', []);
    await fixture.whenStable();
    expect((fixture.nativeElement as HTMLElement).textContent).toContain('Aucun créneau');
  });

  it('affiche le score moyen et la durée de chaque créneau', async () => {
    const fixture = TestBed.createComponent(SlotList);
    fixture.componentRef.setInput('slots', [slot]);
    await fixture.whenStable();
    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';
    expect(text).toContain('88/100');
    expect(text).toContain('4 h');
  });
});
