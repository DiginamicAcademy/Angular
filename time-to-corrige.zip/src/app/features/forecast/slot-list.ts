import { Component, input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Slot } from '../../domain/scoring';

@Component({
  selector: 'app-slot-list',
  imports: [DatePipe],
  template: `
    @for (slot of slots(); track slot.start; let rank = $index) {
      <article class="slot">
        <h3>
          #{{ rank + 1 }} · {{ slot.start | date: 'EEEE d MMMM, HH:mm' }} →
          {{ slot.end | date: 'HH:mm' }}
        </h3>
        <p class="score">Score moyen : {{ slot.averageScore }}/100 · {{ slot.hours }} h</p>
        <p>
          {{ slot.minTemperature }} à {{ slot.maxTemperature }} °C · vent max
          {{ slot.maxWind }} km/h · pluie max {{ slot.maxRainProbability }} %
        </p>
      </article>
    } @empty {
      <p>Aucun créneau favorable sur les prochains jours pour cette activité.</p>
    }
  `,
  styles: `
    .slot { border: 1px solid var(--border); border-radius: 0.5rem; padding: 0.75rem 1rem; margin-block: 0.5rem; }
    .slot h3 { margin: 0 0 0.25rem; font-size: 1rem; }
    .slot h3::first-letter { text-transform: uppercase; }
    .score { font-weight: 600; margin: 0; }
  `,
})
export class SlotList {
  readonly slots = input.required<readonly Slot[]>();
}
