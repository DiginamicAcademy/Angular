import { Component, computed, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Preferences } from '../../core/preferences/preferences';
import { ActivityForm } from './activity-form';

@Component({
  selector: 'app-settings-page',
  imports: [ActivityForm, RouterLink],
  template: `
    <p><a routerLink="/">← Accueil</a></p>
    @if (profile(); as current) {
      <h1>{{ current.emoji }} Réglages : {{ current.label }}</h1>
      <app-activity-form [profile]="current" (saved)="preferences.updateActivity($event)" />
    } @else {
      <p class="error">Activité inconnue.</p>
    }
    <p><button type="button" (click)="preferences.reset()">Rétablir tous les profils par défaut</button></p>
  `,
})
export class SettingsPage {
  protected readonly preferences = inject(Preferences);

  /** Paramètre de route :activite. */
  readonly activite = input.required<string>();

  protected readonly profile = computed(() =>
    this.preferences.activities().find((a) => a.id === this.activite()),
  );
}
