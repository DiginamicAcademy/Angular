import { TestBed } from '@angular/core/testing';
import { DEFAULT_ACTIVITIES } from '../../domain/activities';
import { ActivityProfile } from '../../domain/activity.model';
import { ActivityForm } from './activity-form';

describe('ActivityForm', () => {
  async function setup() {
    const fixture = TestBed.createComponent(ActivityForm);
    fixture.componentRef.setInput('profile', { ...DEFAULT_ACTIVITIES[0] });
    await fixture.whenStable();
    const element = fixture.nativeElement as HTMLElement;
    return { fixture, element };
  }

  /** Simule une saisie utilisateur dans un champ. */
  function type(input: HTMLInputElement, value: string): void {
    input.value = value;
    input.dispatchEvent(new Event('input'));
  }

  it('refuse une température max inférieure à la température min', async () => {
    const { fixture, element } = await setup();

    type(element.querySelector<HTMLInputElement>('#idealMax')!, '10');
    await fixture.whenStable();

    expect(element.textContent).toContain('Doit être supérieure à la température minimale.');
    expect(element.querySelector<HTMLButtonElement>('button[type="submit"]')!.disabled).toBe(true);
  });

  it('émet le profil modifié à l’enregistrement', async () => {
    const { fixture, element } = await setup();
    let saved: ActivityProfile | undefined;
    fixture.componentInstance.saved.subscribe((profile) => (saved = profile));

    type(element.querySelector<HTMLInputElement>('#maxWind')!, '20');
    element.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();

    expect(saved?.maxWind).toBe(20);
    expect(element.textContent).toContain('Profil enregistré.');
  });
});
