import { Component, input, linkedSignal, output, signal } from '@angular/core';
import { FormField, form, max, min, required, submit, validate } from '@angular/forms/signals';
import { ActivityProfile } from '../../domain/activity.model';

@Component({
  selector: 'app-activity-form',
  imports: [FormField],
  templateUrl: './activity-form.html',
  styleUrl: './activity-form.css',
})
export class ActivityForm {
  readonly profile = input.required<ActivityProfile>();
  readonly saved = output<ActivityProfile>();

  /**
   * Copie modifiable du profil reçu. linkedSignal se réinitialise
   * automatiquement quand l'input `profile` change.
   */
  protected readonly model = linkedSignal(() => ({ ...this.profile() }));
  protected readonly confirmation = signal(false);

  protected readonly profileForm = form(this.model, (path) => {
    required(path.label, { message: 'Le nom est obligatoire.' });
    min(path.idealMin, -20, { message: 'Minimum : -20 °C.' });
    max(path.idealMax, 45, { message: 'Maximum : 45 °C.' });
    min(path.tolerance, 1, { message: 'Au moins 1 °C.' });
    min(path.maxWind, 5, { message: 'Au moins 5 km/h.' });
    min(path.maxRainProbability, 0, { message: 'Entre 0 et 100 %.' });
    max(path.maxRainProbability, 100, { message: 'Entre 0 et 100 %.' });
    // Validation croisée : la règle compare deux champs du formulaire.
    validate(path.idealMax, ({ value, valueOf }) =>
      value() <= valueOf(path.idealMin)
        ? { kind: 'range', message: 'Doit être supérieure à la température minimale.' }
        : undefined,
    );
  });

  protected async save(event: Event): Promise<void> {
    event.preventDefault();
    this.confirmation.set(false);
    await submit(this.profileForm, async (field) => {
      this.saved.emit(field().value());
      this.confirmation.set(true);
      return undefined;
    });
  }

  protected cancel(): void {
    this.model.set({ ...this.profile() });
    this.confirmation.set(false);
  }
}
