import { Component, inject, output, signal } from '@angular/core';
import { FormField, debounce, form, minLength } from '@angular/forms/signals';
import { OpenMeteoApi } from '../../core/api/open-meteo-api';
import { GeocodingResult } from '../../core/api/open-meteo.models';
import { Place } from '../../core/api/place.model';

@Component({
  selector: 'app-location-search',
  imports: [FormField],
  templateUrl: './location-search.html',
  styleUrl: './location-search.css',
})
export class LocationSearch {
  private readonly api = inject(OpenMeteoApi);

  /** Émis quand l'utilisateur a choisi un lieu. */
  readonly placeSelected = output<Place>();

  protected readonly searchModel = signal({ query: '' });
  protected readonly searchForm = form(this.searchModel, (path) => {
    // Le modèle n'est mis à jour que 400 ms après la dernière frappe :
    // on évite une requête par caractère saisi.
    debounce(path.query, 400);
    minLength(path.query, 2, { message: 'Saisissez au moins 2 caractères.' });
  });

  protected readonly results = this.api.searchPlaces(() => this.searchModel().query);
  protected readonly geolocationError = signal<string | null>(null);

  protected describe(result: GeocodingResult): string {
    return [result.admin1, result.country].filter(Boolean).join(', ');
  }

  protected select(result: GeocodingResult): void {
    this.placeSelected.emit({
      name: result.name,
      latitude: result.latitude,
      longitude: result.longitude,
    });
  }

  protected locate(): void {
    this.geolocationError.set(null);
    if (!('geolocation' in navigator)) {
      this.geolocationError.set("La géolocalisation n'est pas disponible dans ce navigateur.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) =>
        this.placeSelected.emit({
          name: 'Ma position',
          latitude: Number(position.coords.latitude.toFixed(4)),
          longitude: Number(position.coords.longitude.toFixed(4)),
        }),
      () => this.geolocationError.set('Position refusée ou indisponible.'),
    );
  }
}
