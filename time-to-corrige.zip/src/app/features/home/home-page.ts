import { Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Place } from '../../core/api/place.model';
import { Preferences } from '../../core/preferences/preferences';
import { LocationSearch } from '../search/location-search';

@Component({
  selector: 'app-home-page',
  imports: [LocationSearch, RouterLink],
  template: `
    <h1>Quand sortir cette semaine ?</h1>
    <p>Choisissez un lieu : Time To trouve les meilleurs moments pour votre activité.</p>

    <app-location-search (placeSelected)="open($event)" />

    @if (preferences.lastPlace(); as last) {
      <p>
        Dernier lieu consulté :
        <a [routerLink]="['/prevision', last.latitude, last.longitude]" [queryParams]="{ nom: last.name }">
          {{ last.name }}
        </a>
      </p>
    }
  `,
})
export class HomePage {
  private readonly router = inject(Router);
  protected readonly preferences = inject(Preferences);

  protected open(place: Place): void {
    this.preferences.rememberPlace(place);
    void this.router.navigate(['/prevision', place.latitude, place.longitude], {
      queryParams: { nom: place.name },
    });
  }
}
