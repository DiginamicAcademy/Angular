import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink],
  template: `
    <header>
      <a routerLink="/" class="brand">⏱️ Time To</a>
    </header>
    <main>
      <router-outlet />
    </main>
    <footer>
      Données météo :
      <a href="https://open-meteo.com/" rel="noopener" target="_blank">Open-Meteo</a> (CC BY 4.0)
    </footer>
  `,
})
export class App {}
