import { Component, computed, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DevRepository } from '../../core/data/dev-repository';
import { isDevType } from '../../core/data/dev-validation';
import { Team } from '../../core/team/team';
import { DEV_TYPES } from '../../domain/dev.model';
import { filterDevs } from '../../domain/dev-rules';
import { DevCard } from './dev-card';
import { TypeColor } from '../../shared/directives/type-color';
import { TypeLabelPipe } from '../../shared/pipes/type-label-pipe';
import { EmptyState } from '../../shared/ui/empty-state';

@Component({
  selector: 'app-dex-page',
  imports: [RouterLink, DevCard, EmptyState, TypeColor, TypeLabelPipe],
  template: `
    <h1>Pokédex</h1>

    <nav class="types" aria-label="Filtrer par type">
      <a routerLink="." [queryParams]="{}" [class.active]="!selectedType()">Tous</a>
      @for (type of types; track type) {
        <a
          routerLink="."
          [queryParams]="{ type }"
          [appTypeColor]="type"
          [class.active]="selectedType() === type"
          [attr.aria-current]="selectedType() === type ? 'true' : null"
        >
          {{ type | typeLabel }}
        </a>
      }
    </nav>

    @if (repository.isLoading()) {
      <p role="status">Chargement du pokédex…</p>
    } @else if (repository.error()) {
      <app-empty-state>
        <p class="error">Impossible de charger le pokédex.</p>
        <button actions type="button" (click)="repository.reload()">Réessayer</button>
      </app-empty-state>
    } @else {
      <p class="muted">{{ devs().length }} dev(s)</p>
      <ul class="grid">
        @for (dev of devs(); track dev.id) {
          <li>
            <app-dev-card
              [dev]="dev"
              [inTeam]="team.has(dev.id)"
              [teamFull]="team.isFull()"
              (teamToggled)="team.toggle($event)"
            />
          </li>
        }
      </ul>
    }
  `,
  styleUrl: './dex-page.css',
})
export class DexPage {
  protected readonly repository = inject(DevRepository);
  protected readonly team = inject(Team);

  /** Paramètre de requête ?type=…, lié par withComponentInputBinding(). */
  readonly type = input<string>();

  protected readonly types = DEV_TYPES;
  protected readonly selectedType = computed(() => {
    const type = this.type();
    return isDevType(type) ? type : undefined;
  });
  protected readonly devs = computed(() =>
    filterDevs(this.repository.devs(), { query: '', type: this.selectedType() }),
  );
}
