import { Component, inject } from '@angular/core';
import { DevRepository } from '../../core/data/dev-repository';
import { Team } from '../../core/team/team';
import { EmptyState } from '../../shared/ui/empty-state';
import { DevCard } from './dev-card';

@Component({
  selector: 'app-dex-page',
  imports: [DevCard, EmptyState],
  template: `
    <h1>Pokédex</h1>

    @if (repository.isLoading()) {
      <p role="status">Chargement du pokédex…</p>
    } @else if (repository.error()) {
      <app-empty-state>
        <p class="error">Impossible de charger le pokédex.</p>
        <button actions type="button" (click)="repository.reload()">Réessayer</button>
      </app-empty-state>
    } @else {
      <p>{{ repository.devs().length }} dev(s) · {{ team.size() }} dans l'équipe</p>
      <ul class="grid">
        @for (dev of repository.devs(); track dev.id) {
          <li>
            <app-dev-card
              [dev]="dev"
              [inTeam]="team.has(dev.id)"
              [teamFull]="team.isFull()"
              (teamToggled)="team.toggle($event)"
            />
          </li>
        }
      </ul>
    }
  `,
  styles: `
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(16rem, 1fr));
      gap: 1rem;
      padding: 0;
      list-style: none;
    }
  `,
})
export class DexPage {
  protected readonly repository = inject(DevRepository);
  protected readonly team = inject(Team);
}
