import { Component, inject } from '@angular/core';
import { Loading } from './core/http/loading';
import { Team } from './core/team/team';
import { DexPage } from './features/dex/dex-page';

@Component({
  selector: 'app-root',
  imports: [DexPage],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected readonly loading = inject(Loading);
  protected readonly team = inject(Team);
}
