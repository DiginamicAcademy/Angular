import { Service, computed, inject } from '@angular/core';
import { httpResource } from '@angular/common/http';
import { parseDevs } from './dev-validation';
import { DEVS_URL } from './devs-url';

/** Accès aux devs du pokédex. */
@Service()
export class DevRepository {
  private readonly url = inject(DEVS_URL);
  private readonly remote = httpResource(() => this.url, {
    parse: parseDevs,
    defaultValue: [],
  });

  /** Lire value() d'une ressource en erreur lève une exception : on vérifie hasValue() avant. */
  readonly devs = computed(() => (this.remote.hasValue() ? this.remote.value() : []));
  readonly isLoading = this.remote.isLoading;
  readonly error = this.remote.error;

  byId(id: number) {
    return this.devs().find((dev) => dev.id === id);
  }

  reload(): void {
    this.remote.reload();
  }
}
