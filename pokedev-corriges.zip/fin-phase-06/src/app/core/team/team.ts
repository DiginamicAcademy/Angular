import { Service, computed, signal } from '@angular/core';
import { MAX_TEAM_SIZE } from '../../domain/dev.model';

/** L'équipe, en mémoire et partagée entre les composants. Elle est perdue au rechargement. */
@Service()
export class Team {
  private readonly ids = signal<number[]>([]);

  readonly size = computed(() => this.ids().length);
  readonly isFull = computed(() => this.size() >= MAX_TEAM_SIZE);

  has(id: number): boolean {
    return this.ids().includes(id);
  }

  toggle(id: number): boolean {
    if (this.has(id)) {
      this.ids.update((ids) => ids.filter((current) => current !== id));
      return true;
    }
    if (this.isFull()) {
      return false;
    }
    this.ids.update((ids) => [...ids, id]);
    return true;
  }
}
