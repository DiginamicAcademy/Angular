import { Component } from '@angular/core';
import { DexPage } from './features/dex/dex-page';

@Component({
  selector: 'app-root',
  imports: [DexPage],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {}
