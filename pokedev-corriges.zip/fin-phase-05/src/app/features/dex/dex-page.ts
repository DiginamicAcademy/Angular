import { Component, signal } from '@angular/core';
import { EmptyState } from '../../shared/ui/empty-state';
import { DevCard } from './dev-card';
import { MOCK_DEVS } from './mock-devs';

@Component({
  selector: 'app-dex-page',
  imports: [DevCard, EmptyState],
  template: `
    <h1>Pokédex</h1>
    <p>{{ devs().length }} dev(s) · {{ teamIds().length }} dans l'équipe</p>
    <button type="button" (click)="devs.set([])">Vider la liste</button>

    @if (devs().length > 0) {
      <ul class="grid">
        @for (dev of devs(); track dev.id) {
          <li>
            <app-dev-card
              [dev]="dev"
              [inTeam]="teamIds().includes(dev.id)"
              (teamToggled)="toggle($event)"
            />
          </li>
        }
      </ul>
    } @else {
      <app-empty-state>
        <p>Aucun dev.</p>
        <button actions type="button" (click)="devs.set(MOCK_DEVS)">Recharger</button>
      </app-empty-state>
    }
  `,
  styles: `
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(16rem, 1fr));
      gap: 1rem;
      padding: 0;
      list-style: none;
    }
  `,
})
export class DexPage {
  protected readonly MOCK_DEVS = MOCK_DEVS;
  protected readonly devs = signal(MOCK_DEVS);
  protected readonly teamIds = signal<number[]>([]);

  protected toggle(id: number): void {
    this.teamIds.update((ids) =>
      ids.includes(id) ? ids.filter((current) => current !== id) : [...ids, id],
    );
  }
}
