import { Component, computed, input, output } from '@angular/core';
import { Dev, STAT_KEYS } from '../../domain/dev.model';
import { totalStats } from '../../domain/dev-rules';
import { STAT_LABELS } from '../../domain/labels';
import { StatBar } from '../../shared/ui/stat-bar';
import { RankLabel } from './rank-label';

@Component({
  selector: 'app-dev-card',
  imports: [StatBar, RankLabel],
  template: `
    <article class="card" [class.in-team]="inTeam()">
      <p>#{{ dev().id }}</p>
      <h3>{{ dev().name }}</h3>
      <p>{{ dev().title }}</p>
      <p>
        @for (type of dev().types; track type) {
          <span class="type">{{ type }}</span>
        }
      </p>
      <p>Total : {{ total() }} · <app-rank-label [total]="total()" /></p>
      @for (key of statKeys; track key) {
        <app-stat-bar [label]="statLabels[key]" [value]="dev().stats[key]" />
      }
      <button type="button" (click)="teamToggled.emit(dev().id)">
        {{ inTeam() ? 'Retirer de l’équipe' : 'Ajouter à l’équipe' }}
      </button>
    </article>
  `,
  styles: `
    .card {
      padding: 1rem;
      border: 1px solid var(--border);
      border-radius: 0.75rem;
    }
    .card.in-team {
      border-color: var(--accent);
      box-shadow: 0 0 0 1px var(--accent);
    }
    .type {
      margin-right: 0.25rem;
      padding: 0 0.5rem;
      border: 1px solid var(--border);
      border-radius: 999px;
    }
  `,
})
export class DevCard {
  readonly dev = input.required<Dev>();
  readonly inTeam = input(false);
  readonly teamToggled = output<number>();

  protected readonly statKeys = STAT_KEYS;
  protected readonly statLabels = STAT_LABELS;
  protected readonly total = computed(() => totalStats(this.dev().stats));
}
